import java.lang.System;
import java.util.Scanner;

public class MultiplicationTables {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Welcome to Multiplication Tables");
        System.out.println("How large would you like to see them?");
        int size = keyboard.nextInt();

        for (int a = 0; a <= size; a++) {
            for (int b = 0; b <= size; b++) {
                System.out.println(a + "*" + b + "=" + (a * b));
            }
            System.out.println();
        }
    }
}




