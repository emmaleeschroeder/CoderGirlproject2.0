import static java.lang.System.out;
import java.util.Scanner;

public class CountTo30 {

    public static void main (String[] args){
        int a = 1;
        System.out.println("Count to 30");

        while (a <= 30)
        {
            System.out.println(a);
            a++;
        }
    }

}
