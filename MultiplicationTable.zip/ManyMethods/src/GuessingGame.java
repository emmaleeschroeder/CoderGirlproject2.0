import static java.lang.System.out;
import java.util.Scanner;

public class GuessingGame {

    public static void guessingGame() {
        Scanner keyboard = new Scanner(System.in);
        int guessNumber;
        boolean userNumber = true;
        System.out.println("Im thinking of a number between 1 and 100, What is it?");

        do {
                guessNumber = keyboard.nextInt();
            if (guessNumber > 100 || guessNumber < 1) {
                System.out.print("Oops! That number wasn't between 1 and 100.. Try again :)");
            } else if (guessNumber > 11) {
                System.out.print("Lower");
            } else if (guessNumber < 11) {
                System.out.print("Higher");
            } else {
                System.out.print("yay!");
            }

        } while (userNumber);

    }

   public static void playAgain() {
       Scanner keyboard = new Scanner(System.in);
       String playAgain;
       System.out.println("Do you want to play again?");
       playAgain = keyboard.nextLine();
       if (playAgain.equals("yes")) ;
       guessingGame();

   }

    public static void main(String[] args) {
        guessingGame();
        playAgain();

    }
}