import java.util.Scanner;
public class For {

    public static void main(String[] args) {
        int userNumber;
        Scanner keyboard = new Scanner(System.in);
        System.out.println("How big of a number should i count too?");
        userNumber = keyboard.nextInt();

        for (int a = 1; userNumber >= a; a++) {
            System.out.print(a);
        }
        System.out.println();

        for (int a = 0; userNumber > a; ) {
            System.out.print(userNumber--);
        }
    }
}






