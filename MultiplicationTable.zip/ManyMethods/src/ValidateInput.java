import static java.lang.System.out;
import java.util.Scanner;

public class ValidateInput {



    public static int getIntegerBetween() {
        Scanner keyboard = new Scanner(System.in);
        int firstNumber;
        boolean numberBetween = true;
        do {
            firstNumber = keyboard.nextInt();
            if (firstNumber < 1 || firstNumber > 10) {
                System.out.println("Error, Try again.");
                numberBetween = false;
            } else {
                break;
            }

        } while (!numberBetween) ;
            return firstNumber;

    }

    public static int getTensInteger() {
        Scanner keyboard = new Scanner(System.in);
        int secondNumber;
        boolean divTen = true;
        do {
            secondNumber = keyboard.nextInt();
            if (secondNumber > 3000 || secondNumber < 200)
                {
                    System.out.print("Error, Try again.");
                    divTen = false;
                }
        } while (!divTen);
            return secondNumber;
        }

    public static void main (String[]args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Please enter in a number from 1-10.");
            int firstNumber = getIntegerBetween();
            System.out.println("Please enter a number between 200 and 3000 that is a multiple of ten");
            int secondNumber = getTensInteger();

            System.out.println("You entered " + firstNumber + " and " + secondNumber);

        }
   }

