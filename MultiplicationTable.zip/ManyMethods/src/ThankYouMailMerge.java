import java.util.Scanner;

import static java.lang.System.*;

public class ThankYouMailMerge {

    public static void main(String[] args) {
        System.out.println("---Thank You Letter---");
        Scanner keyboard = new Scanner(System.in);
        String personName;
        float dollarAmount;
        boolean keepGoing = true;


        while (keepGoing == true) {

            System.out.println("Enter a person name:");
            personName = keyboard.nextLine();
            if (personName.equals("quit")) {
                break;
            }
            System.out.println("Donation: ?");
            dollarAmount = keyboard.nextFloat();
            keyboard.skip("\n");

            System.out.println("Dear " + personName + " Thank you for your donation! We rely on donors like you to keep our\n" +
                    "organization effective, and you came through for us. Your donation of $" + dollarAmount +
                    " will help our efforts to make a difference in the world.\n" +
                    "As you may know, we are a registered non-profit organization, so your\n" +
                    "donation is tax deductible. You may use this letter as a receipt for tax\n" +
                    "purposes.\n" +
                    "Thank you again for your support!\n" +
                    "Sincerely,\n" +
                    "Paula Jones\n" +
              "YourCharity.org");
        }
    }
}