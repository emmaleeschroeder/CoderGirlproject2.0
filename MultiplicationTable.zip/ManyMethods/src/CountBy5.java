import static java.lang.System.out;

public class CountBy5 {

    public static void main (String[] args) {
        int a = 0;
        System.out.print("Count to 100 by 5");
        while (a <= 100) {

            System.out.println(a);
            a = a + 5;
        }

    }
}