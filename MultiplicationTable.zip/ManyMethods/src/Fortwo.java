import java.util.Scanner;
import java.lang.System;

public class Fortwo {

    public static void main(String[] args) {
        System.out.println("Welcome to Bar Chart!");
        barChart();
    }

    public static void barChart() {
        Scanner keyboard = new Scanner(System.in);
        int userNumber;
        boolean keepGoing = true;

        while (keepGoing) {
            System.out.println("Number?");
            userNumber = keyboard.nextInt();
            int b = userNumber;
            for (int a = 0; a < b; a++) {
                System.out.print("#");
            }
            System.out.println();
            if (userNumber == 0) {
                keepGoing = false;
                System.out.println("have a good day!");
            }
        }
    }
}
