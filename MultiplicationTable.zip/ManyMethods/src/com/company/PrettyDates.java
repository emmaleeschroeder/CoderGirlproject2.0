package com.company;
import static java.lang.System.out;
import java.util.Scanner;

public class PrettyDates {
    // formatNumberAsTwoDigits
    // nameFormat
    // slashFormat
    // dash Format
    //---- end of your work area ---
    //dont change this code.

    public static String formatNumberAsTwoDigits(int number) {

        if (number < 10) {
            return "0" + number;
        } else {
            return String.valueOf(number);
        }
    }

     public static String slashFormat(int year, int month, int day){
            String formattedMonth = formatNumberAsTwoDigits(month);
            String formattedDay = formatNumberAsTwoDigits(day);
            return formattedMonth + "/" + formattedDay + "/" + year;
        }

     public static String dashFormat (int year, int month, int day){
            return year + "-" + formatNumberAsTwoDigits(month) + "-" +
                    formatNumberAsTwoDigits(day);
        }

        public static String nameFormat(int year, int month, int day) {
            String textMonth;
            if (month == 1) {
                textMonth = "January";
            } else if (month == 10) {
                textMonth = "October";
            } else if (month == 12) {
                textMonth = "December";
            }
            return "";
        }
    public static void printDate(int year, int month, int day) {
        System.out.println(nameFormat(year, month, day));
        System.out.println(slashFormat(year, month, day));
        System.out.println(dashFormat(year, month, day));
        System.out.println();
    }
    //dont change this code.

    public static void main(String[] args) {
        System.out.println(formatNumberAsTwoDigits(3));
        System.out.println(formatNumberAsTwoDigits(9));
        System.out.println(formatNumberAsTwoDigits(10));
        System.out.println(formatNumberAsTwoDigits(12));

        printDate(2014, 10, 4);
        printDate(2015, 1, 1);
        printDate(2013, 12, 31);
    }
}


