import static java.lang.System.out;

import java.util.Scanner;

public class AddingMachine {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Hi welcome to adding machine!");
        System.out.println("Total: 0");

        float total = 0;
        float sumOfTotal = keyboard.nextFloat();
        boolean keepGoing = true;
        int Count = 0;

        while (sumOfTotal > 0) {
            Count++;
            System.out.println("Add:");
            total = keyboard.nextFloat();
            if (total == 0) break;
            sumOfTotal = total + sumOfTotal;

        }
        System.out.println("total:" + (total + sumOfTotal));
        System.out.println(("You entered " + Count + " numbers"));
    }
}




