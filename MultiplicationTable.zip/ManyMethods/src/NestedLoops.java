import java.lang.System;

public class NestedLoops {
   public static void main(String[] args) {
       for (int rows = 0; rows < 6; rows++) {
          for (int columns = 0; columns < 8; columns++) {
               System.out.print("#");
            }
            System.out.println();
        }
    }
}

//public class NestedLoops {
  //  public static void main(String[] args) {
    //    int rows = 0;
      //  while (rows++ < 8) {
        //    for (int columns = 0; columns < 4; columns++) {
          //      System.out.print("#");
            //}
            //System.out.println();
            //for (int columns = 0; columns < 4; columns++) {
              //  System.out.print("-");
            //}
            //System.out.println();
        //}
    //}

//}