import static java.lang.System.out;
import java.util.Scanner;

public class AreWeThereYet {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String WeThereYet;
        boolean keepGoing = true;

        while (keepGoing == true) {
            System.out.print("Are we there yet? ");
            WeThereYet = keyboard.nextLine();
            if (WeThereYet.equals("no")) {
            } else if (WeThereYet.equals("yes")) {
                keepGoing = false;
            } else {
                System.out.println("Huh? i didn't understand that!");
            }
        }
          System.out.println("yay!");
        }
    }